<?php

namespace Database\Factories;

use App\Models\Product;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Product>
 */
use Faker\Generator as Faker;

class ProductFactory extends Factory
{
    protected $model = Product::class;

    public function definition()
    {
        $categories = ['Roti', 'Yogurt', 'Susu'];
        $category = $this->faker->randomElement($categories);

        // Daftar merek Roti
        $rotiBrands = [
            'Sari Roti', 
            'BreadTalk', 
            'Tous Les Jours', 
            'BreadLife', 
            'Mr. Bread', 
            'Holland Bakery', 
            'Bread Story', 
            'Roti O', 
            'Roti Boy', 
            'Roti Tawar'
        ];

        // Daftar merek Yogurt
        $yogurtBrands = [
            'Yoplait', 
            'Chobani', 
            'Fage', 
            'Danone', 
            'Activia', 
            'Yakult', 
            'Greenfields', 
            'Heavenly Blush', 
            'Cimory', 
            'Biokul'
        ];

        // Daftar merek Susu
        $susuBrands = [
            'Frisian Flag', 
            'Indomilk', 
            'Dancow', 
            'Ultra Milk', 
            'Bear Brand', 
            'Greenfields', 
            'Nestle', 
            'Milo', 
            'Anlene', 
            'Enfagrow'
        ];

        $name = $category == 'Roti'
            ? $this->faker->randomElement($rotiBrands)
            : ($category == 'Yogurt'
                ? $this->faker->randomElement($yogurtBrands)
                : $this->faker->randomElement($susuBrands));

        // Deskripsi khusus untuk setiap kategori
        $description = $category == 'Roti'
            ? 'Roti dengan rasa yang lezat dan tekstur yang lembut, ideal untuk sarapan atau cemilan.'
            : ($category == 'Yogurt'
                ? 'Yogurt segar dengan kandungan probiotik tinggi, baik untuk pencernaan.'
                : 'Susu berkualitas tinggi dengan rasa yang nikmat dan kaya akan nutrisi.');

        return [
            'name' => $name,
            'description' => $description,
            'price' => $this->faker->numberBetween(5000, 100000),
            'image' => $this->faker->imageUrl(640, 480, 'product', true),
            'category_id' => $category == 'Roti' ? 1 : ($category == 'Yogurt' ? 2 : 3),
            'expired_at' => now()->addDays(30),
            'modified_by' => $this->faker->randomElement(['admin@gmail.com','tingTing@gmail.com' ,'user@gmail.com'])
        ];
    }
}

